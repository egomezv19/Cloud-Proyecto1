package com.example.microservice_estudiante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceEstudianteApplicationTests {

    @Test
    void contextLoads() {
    }

}
