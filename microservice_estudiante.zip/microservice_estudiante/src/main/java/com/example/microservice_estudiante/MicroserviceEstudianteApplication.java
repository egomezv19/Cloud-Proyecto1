package com.example.microservice_estudiante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceEstudianteApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroserviceEstudianteApplication.class, args);
    }

}
